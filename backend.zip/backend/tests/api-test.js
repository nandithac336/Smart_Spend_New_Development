
const BASE_URL = "http://localhost:5000";

const tests = [
  {
    name: "Backend Health Check",
    url: "/api/health",
    expectedStatus: 200,
  },
  {
    name: "MongoDB Connection Check",
    url: "/api/health/db",
    expectedStatus: 200,
  },
];

async function runTests() {
  let passed = 0;
  let failed = 0;

  console.log("\n===== SMARTSPEND API TESTING =====\n");

  for (const test of tests) {
    try {
      const response = await fetch(BASE_URL + test.url);
      const data = await response.json();

      if (response.status === test.expectedStatus && data.success === true) {
        console.log(`PASS: ${test.name}`);
        passed++;
      } else {
        console.log(`FAIL: ${test.name}`, response.status, data);
        failed++;
      }
    } catch (error) {
      console.log(`FAIL: ${test.name}`, error.message);
      failed++;
    }
  }

  console.log("\n===== TEST SUMMARY =====");
  console.log("Passed:", passed);
  console.log("Failed:", failed);
  console.log("Total:", passed + failed);
}

runTests();
