import { useEffect, useRef, useState } from 'react'
import { CalendarDays, RefreshCw, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button.jsx'
import ErrorState from '@/components/common/ErrorState.jsx'
import { useAuth } from '@/hooks/useAuth.js'
import { useDashboard } from '@/hooks/useDashboard.js'
import { useMotionDisabled } from '@/hooks/useMotionDisabled.js'
import DashboardLoading from '@/components/dashboard/DashboardLoading.jsx'
import { DashboardSummary, DashboardWallets } from '@/components/dashboard/DashboardSummary.jsx'
import DashboardSpending from '@/components/dashboard/DashboardSpending.jsx'
import '@/components/dashboard/Dashboard.css'

function formatToday(timeZone) {
  return new Intl.DateTimeFormat('en-IN', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    timeZone,
  }).format(new Date())
}

function formatPeriod(period, timeZone) {
  if (!period?.monthStart) return 'This month'
  const monthStart = new Date(period.monthStart)
  if (Number.isNaN(monthStart.getTime())) return 'This month'

  return new Intl.DateTimeFormat('en-IN', {
    month: 'long',
    year: 'numeric',
    timeZone,
  }).format(monthStart)
}

const DASHBOARD_ENTRANCE_KEY = 'smart-spend-dashboard-entrance-seen'

function Dashboard() {
  const { user } = useAuth()
  const { data, isPending, isFetching, isError, refetch } = useDashboard()
  const motionDisabled = useMotionDisabled()
  const [animateEntrance] = useState(() => {
    try {
      return window.sessionStorage.getItem(DASHBOARD_ENTRANCE_KEY) !== 'true'
    } catch {
      // Session storage can be blocked in private mode; skip the entrance animation.
      return false
    }
  })
  const [highlightedTransactionIds, setHighlightedTransactionIds] = useState(() => new Set())
  const previousTransactionIds = useRef(null)
  const timeZone = data?.period?.timezone || user?.timezone || 'Asia/Kolkata'
  const firstName = user?.name?.trim().split(/\s+/)[0] || 'there'
  const showEntrance = animateEntrance && !motionDisabled

  useEffect(() => {
    if (isPending || !data || !animateEntrance) return
    try {
      window.sessionStorage.setItem(DASHBOARD_ENTRANCE_KEY, 'true')
    } catch {
      // Session storage can be blocked in private mode; skip replay persistence.
    }
  }, [animateEntrance, data, isPending])

  useEffect(() => {
    if (!data || isPending) return
    const ids = (data.recent ?? [])
      .map((transaction) => transaction.id ?? transaction._id)
      .filter(Boolean)

    if (previousTransactionIds.current === null) {
      previousTransactionIds.current = new Set(ids)
      return
    }

    const previousIds = previousTransactionIds.current
    previousTransactionIds.current = new Set(ids)
    const newIds = ids.filter((id) => !previousIds.has(id))
    if (newIds.length > 0) {
      setHighlightedTransactionIds((current) => new Set([...current, ...newIds]))
    }
  }, [data, isPending])

  if (isPending) return <DashboardLoading />

  if (isError || !data) {
    return (
      <div className="dashboard-page">
        <ErrorState
          description="Your dashboard couldn’t be loaded. Check your connection and try again."
          onRetry={() => refetch()}
          title="Couldn’t load dashboard"
        />
      </div>
    )
  }

  const greeting = `Good day, ${firstName}`

  return (
    <div className={`dashboard-page space-y-5 sm:space-y-6 ${showEntrance ? 'dashboard-entrance' : ''}`}>
      <header className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-primary">
            <Sparkles aria-hidden="true" className="size-4" />
            Your money, in focus
          </p>
          <h1 className="mt-2 text-2xl font-bold tracking-tight sm:text-3xl" aria-label={greeting}>
            {greeting}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">{formatToday(timeZone)}</p>
        </div>
        <div className="flex items-center justify-between gap-3 sm:justify-end">
          <span className="dashboard-period-pill inline-flex items-center gap-2 rounded-full px-3 py-2 text-xs font-medium">
            <CalendarDays aria-hidden="true" className="size-4 text-primary" />
            {formatPeriod(data.period, timeZone)}
          </span>
          <Button
            aria-label="Refresh dashboard"
            className="dashboard-refresh"
            disabled={isFetching}
            onClick={() => refetch()}
            size="icon"
            variant="outline"
          >
            <RefreshCw aria-hidden="true" className={isFetching && !motionDisabled ? 'animate-spin' : ''} />
          </Button>
        </div>
      </header>

      <DashboardSummary data={data} animated={showEntrance} />
      <DashboardWallets
        animated={showEntrance}
        motionDisabled={motionDisabled}
        wallets={data.wallets ?? []}
      />
      <DashboardSpending
        categories={data.topCategories ?? []}
        expenses={data.monthSpent ?? 0}
        monthExpenses={data.monthExpenses ?? []}
        highlightedTransactionIds={highlightedTransactionIds}
        recent={data.recent ?? []}
        timeZone={timeZone}
        animated={showEntrance}
        motionDisabled={motionDisabled}
      />
    </div>
  )
}

export default Dashboard
