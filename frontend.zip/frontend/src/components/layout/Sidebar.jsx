import { LayoutDashboard, Settings, Wallet, ReceiptText } from 'lucide-react'
import { NavLink, Link } from 'react-router-dom'
import { m } from 'motion/react'
import ThemeToggle from '@/components/common/ThemeToggle.jsx'
import LogoutButton from './LogoutButton.jsx'
import { useMotionDisabled } from '@/hooks/useMotionDisabled.js'

const links = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/transactions', label: 'Transactions', icon: ReceiptText },
  { to: '/wallets', label: 'Wallets', icon: Wallet },
  { to: '/settings', label: 'Settings', icon: Settings },
]

function Sidebar({ user }) {
  const motionDisabled = useMotionDisabled()

  return (
    <aside className="glass-strong fixed inset-y-0 left-0 z-30 hidden w-72 flex-col rounded-none border-y-0 border-l-0 px-5 py-6 lg:flex">
      <Link className="flex items-center gap-3 px-2 text-lg font-bold tracking-tight" to="/dashboard">
        <span className="flex size-10 items-center justify-center rounded-2xl bg-primary text-primary-foreground">S</span>
        <span>Smart Spend</span>
      </Link>

      <nav aria-label="Main navigation" className="mt-10 space-y-1">
        {links.map(({ to, label, icon: Icon }) => (
          <NavLink
            className={({ isActive }) => `group relative flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-medium transition-colors ${isActive ? 'text-primary' : 'text-muted-foreground hover:text-foreground'}`}
            end={to === '/dashboard'}
            key={to}
            to={to}
          >
            {({ isActive }) => (
              <>
                {isActive && (
                  <m.span
                    className="absolute inset-0 rounded-xl bg-primary/10"
                    layoutId="sidebar-active-pill"
                    transition={motionDisabled ? { duration: 0 } : { type: 'spring', stiffness: 520, damping: 38 }}
                  />
                )}
                <Icon aria-hidden="true" className="relative z-10 size-[18px] transition-transform duration-200 group-hover:translate-x-0.5" />
                <span className="relative z-10">{label}</span>
              </>
            )}
          </NavLink>
        ))}
      </nav>

      <div className="mt-auto space-y-5">
        <ThemeToggle />
        <div className="flex items-center gap-3 border-t border-border pt-5">
          <span aria-hidden="true" className="flex size-10 shrink-0 items-center justify-center rounded-full bg-accent text-sm font-semibold text-accent-foreground">
            {user?.name?.trim()?.charAt(0)?.toUpperCase() || '?'}
          </span>
          <span className="min-w-0 flex-1 truncate text-sm font-medium" title={user?.name}>
            {user?.name || 'Account'}
          </span>
          <LogoutButton aria-label="Log out" className="size-9 px-0" showLabel={false} />
        </div>
      </div>
    </aside>
  )
}

export default Sidebar
