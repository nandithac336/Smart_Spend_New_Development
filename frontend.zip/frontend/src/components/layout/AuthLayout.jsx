import { useEffect } from 'react'
import { m, useAnimate } from 'motion/react'
import { ArrowUpRight, Banknote, Smartphone, Sparkles } from 'lucide-react'
import { Link } from 'react-router-dom'
import AuroraBackground from '@/components/common/AuroraBackground.jsx'
import { useMotionDisabled } from '@/hooks/useMotionDisabled.js'

const illustrations = [
  { icon: Banknote, title: 'Cash and UPI', detail: 'in one clear view' },
  { icon: Smartphone, title: '₹40 added to Food', detail: 'A little clarity, every day' },
  { icon: Sparkles, title: 'Your money, in focus', detail: 'Spend smarter, one step at a time' },
]

function AuthLayout({ children, className = '', failedAttempt = 0 }) {
  const motionDisabled = useMotionDisabled()
  const [scope, animate] = useAnimate()

  useEffect(() => {
    if (failedAttempt === 0 || motionDisabled) return

    animate(
      scope.current,
      { x: [0, -7, 7, -5, 5, 0] },
      { duration: 0.36, ease: 'easeInOut' },
    )
  }, [animate, failedAttempt, motionDisabled, scope])

  return (
    <main className="relative isolate min-h-screen overflow-hidden px-4 py-8 sm:px-6 lg:grid lg:grid-cols-2 lg:items-stretch lg:gap-8 lg:px-8 lg:py-6">
      <section className="relative hidden min-h-[calc(100vh-3rem)] overflow-hidden rounded-[2rem] border border-white/30 dark:border-white/10 lg:flex lg:flex-col lg:justify-between lg:p-10 xl:p-14">
        <AuroraBackground animated />
        <Link className="relative z-10 w-fit text-lg font-bold tracking-tight" to="/">
          Smart Spend<span className="text-primary">.</span>
        </Link>

        <div className="relative z-10 max-w-xl">
          <p className="mb-4 text-xs font-semibold uppercase tracking-[0.2em] text-primary">
            A little more clarity
          </p>
          <h1 className="text-4xl font-bold leading-tight tracking-tight xl:text-5xl">
            Track every rupee.
            <br />
            Spend smarter.
          </h1>
          <p className="mt-4 max-w-md text-base leading-relaxed text-muted-foreground">
            Make everyday spending easier to understand, one small entry at a time.
          </p>

          <div className="relative mt-9 grid max-w-md gap-3">
            {illustrations.map(({ icon: Icon, title, detail }, index) => (
              <m.div
                key={title}
                className="glass flex items-center gap-3 rounded-2xl p-4"
                initial={motionDisabled ? false : { opacity: 0, y: 10 }}
                animate={motionDisabled ? { opacity: 1, y: 0 } : { opacity: 1, y: [0, -5, 0] }}
                transition={{
                  duration: motionDisabled ? 0 : 3.2,
                  delay: motionDisabled ? 0 : 0.1 * index,
                  repeat: motionDisabled ? 0 : Infinity,
                  ease: 'easeInOut',
                }}
              >
                <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <Icon aria-hidden="true" className="size-5" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-sm font-semibold">{title}</span>
                  <span className="block text-xs text-muted-foreground">{detail}</span>
                </span>
                {index === 0 && <ArrowUpRight aria-hidden="true" className="size-4 text-primary" />}
              </m.div>
            ))}
          </div>
        </div>

        <p className="relative z-10 text-xs text-muted-foreground">Illustration · Demo content, not account data</p>
      </section>

      <section className="flex min-h-[calc(100vh-4rem)] items-center justify-center py-8 lg:min-h-0 lg:py-0">
        <m.div
          ref={scope}
          className={`glass-strong w-full max-w-md rounded-[1.75rem] p-6 shadow-2xl shadow-green-950/5 sm:p-8 ${className}`}
        >
          <div className="mb-7 lg:hidden">
            <Link className="text-sm font-bold tracking-tight" to="/">
              Smart Spend<span className="text-primary">.</span>
            </Link>
            <p className="mt-2 text-xs text-muted-foreground">Track every rupee. Spend smarter.</p>
          </div>
          {children}
        </m.div>
      </section>
    </main>
  )
}

export default AuthLayout
