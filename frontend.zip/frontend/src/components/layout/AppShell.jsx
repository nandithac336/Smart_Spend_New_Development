import { useEffect, useState } from 'react'
import { Outlet, Link } from 'react-router-dom'
import { useAuth } from '@/hooks/useAuth.js'
import ThemeToggle from '@/components/common/ThemeToggle.jsx'
import Sidebar from './Sidebar.jsx'
import BottomNav from './BottomNav.jsx'
import AddButton from './AddButton.jsx'
import { useCategories } from '@/hooks/useCategories.js'
import { useWallets } from '@/hooks/useWallets.js'

function AppShell() {
  const { user } = useAuth()
  useCategories('expense')
  useCategories('income')
  useWallets()
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    function handleScroll() {
      setScrolled(window.scrollY > 8)
    }
    handleScroll()
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <div className="min-h-screen">
      <Sidebar user={user} />
      <div className="min-h-screen lg:pl-72">
        <main className="mx-auto min-h-screen w-full max-w-6xl px-4 pt-6 pb-[calc(6rem+env(safe-area-inset-bottom))] sm:px-6 sm:pt-8 lg:px-10 lg:pb-28">
          <header className={`sticky top-0 z-20 -mx-4 mb-5 flex h-14 items-center justify-between px-4 transition-colors sm:-mx-6 sm:px-6 lg:hidden ${scrolled ? 'border-b border-border/70 bg-background/80 backdrop-blur-xl' : 'border-b border-transparent bg-transparent'}`}>
            <Link className="flex items-center gap-2 text-sm font-bold tracking-tight" to="/dashboard">
              <span className="flex size-8 items-center justify-center rounded-xl bg-primary text-primary-foreground">S</span>
              Smart Spend
            </Link>
            <ThemeToggle compact />
          </header>
          <Outlet />
        </main>
      </div>
      <BottomNav />
      <AddButton />
    </div>
  )
}

export default AppShell
