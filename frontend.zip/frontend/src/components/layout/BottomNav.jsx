import { LayoutDashboard, Settings, Wallet, ReceiptText } from 'lucide-react'
import { NavLink } from 'react-router-dom'
import { m } from 'motion/react'
import AddButton from './AddButton.jsx'
import { useMotionDisabled } from '@/hooks/useMotionDisabled.js'

const leftLinks = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/transactions', label: 'Transactions', icon: ReceiptText },
]

const rightLinks = [
  { to: '/wallets', label: 'Wallets', icon: Wallet },
  { to: '/settings', label: 'Settings', icon: Settings },
]

function BottomNav() {
  const motionDisabled = useMotionDisabled()

  function renderLink({ to, label, icon: Icon }) {
    return (
      <NavLink
        aria-label={label}
        className={({ isActive }) => `relative flex min-w-0 flex-1 flex-col items-center justify-center gap-1 text-[10px] font-medium ${isActive ? 'text-primary' : 'text-muted-foreground'}`}
        end={to === '/dashboard'}
        key={to}
        to={to}
      >
        {({ isActive }) => (
          <>
            {isActive && (
              <m.span
                className="absolute -top-2 h-1 w-7 rounded-full bg-primary"
                layoutId="bottom-nav-active-indicator"
                transition={motionDisabled ? { duration: 0 } : { type: 'spring', stiffness: 500, damping: 36 }}
              />
            )}
            <Icon aria-hidden="true" className="size-5" />
            <span className="max-w-full truncate">{label}</span>
          </>
        )}
      </NavLink>
    )
  }

  return (
    <nav aria-label="Main navigation" className="fixed inset-x-0 bottom-3 z-40 px-3 pb-[max(env(safe-area-inset-bottom),0.25rem)] lg:hidden">
      <div className="glass-strong mx-auto flex h-[4.25rem] max-w-lg items-center justify-around rounded-[1.6rem] px-1.5 shadow-[0_12px_38px_rgb(16_40_24/14%)]">
        {leftLinks.map(renderLink)}
        <div className="flex flex-1 justify-center">
          <AddButton placement="nav" />
        </div>
        {rightLinks.map(renderLink)}
      </div>
    </nav>
  )
}

export default BottomNav
