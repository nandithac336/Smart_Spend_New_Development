import { useState } from 'react'
import { LogOut } from 'lucide-react'
import { toast } from 'sonner'
import { useAuth } from '@/hooks/useAuth.js'
import { Button } from '@/components/ui/button.jsx'
import Loader from '@/components/common/Loader.jsx'

function LogoutButton({ className, variant = 'ghost', showLabel = true }) {
  const { logout } = useAuth()
  const [pending, setPending] = useState(false)

  async function handleLogout() {
    setPending(true)
    try {
      await logout()
    } catch {
      toast.error('You were signed out, but the server could not be reached.')
    } finally {
      setPending(false)
    }
  }

  return (
    <Button className={className} disabled={pending} onClick={handleLogout} variant={variant}>
      {pending ? <Loader label="Signing out" /> : <LogOut aria-hidden="true" />}
      {showLabel && <span>{pending ? 'Signing out…' : 'Log out'}</span>}
    </Button>
  )
}

export default LogoutButton
