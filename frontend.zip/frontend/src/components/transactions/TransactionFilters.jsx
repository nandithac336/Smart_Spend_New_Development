import { useEffect, useState } from 'react'
import { Filter, Search, X } from 'lucide-react'
import { AnimatePresence, m } from 'motion/react'
import { useCategories } from '@/hooks/useCategories.js'
import { useMotionDisabled } from '@/hooks/useMotionDisabled.js'
import { useWallets } from '@/hooks/useWallets.js'
import { toPaise } from '@/lib/money.js'
import { dateOnlyRangeToIso, datePresetRange } from '@/lib/transactionDates.js'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet.jsx'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select.jsx'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'

const EMPTY_FILTERS = ['q', 'type', 'walletId', 'categoryId', 'datePreset', 'from', 'to', 'minAmount', 'maxAmount', 'tag']
const TYPE_OPTIONS = [
  ['all', 'All types'],
  ['expense', 'Expense'],
  ['income', 'Income'],
  ['transfer', 'Transfer'],
]
const DATE_OPTIONS = [
  ['none', 'Any date'],
  ['today', 'Today'],
  ['week', 'This week'],
  ['month', 'This month'],
  ['custom', 'Custom'],
]

function FilterFields({ params, setParams, timeZone }) {
  const type = params.get('type') ?? 'all'
  const datePreset = params.get('datePreset') ?? 'none'
  const { data: walletData } = useWallets()
  const wallets = walletData?.wallets ?? walletData ?? []
  const categoryType = type === 'expense' || type === 'income' ? type : undefined
  const { data: categories = [] } = useCategories(categoryType)
  const motionDisabled = useMotionDisabled()

  function update(key, value) {
    setParams((current) => {
      const next = new URLSearchParams(current)
      const previousValue = next.get(key)
      if (!value || value === 'all' || value === 'none') next.delete(key)
      else next.set(key, value)

      if (key === 'type' && value !== previousValue) next.delete('categoryId')
      if (key === 'datePreset') {
        if (value !== 'custom') {
          next.delete('fromDate')
          next.delete('toDate')
          next.delete('from')
          next.delete('to')
        } else {
          next.delete('from')
          next.delete('to')
          const range = dateOnlyRangeToIso(next.get('fromDate') ?? '', next.get('toDate') ?? '', timeZone)
          if (range.from) next.set('from', range.from)
          if (range.to) next.set('to', range.to)
        }
        if (value && value !== 'none' && value !== 'custom') {
          const range = datePresetRange(value, timeZone)
          next.set('from', range.from)
          next.set('to', range.to)
        }
      }
      return next
    }, { replace: true })
  }

  function updateCustomDate(key, value) {
    setParams((current) => {
      const next = new URLSearchParams(current)
      next.set('datePreset', 'custom')
      const values = {
        from: key === 'from' ? value : next.get('fromDate') ?? '',
        to: key === 'to' ? value : next.get('toDate') ?? '',
      }
      if (key === 'from') {
        if (value) next.set('fromDate', value)
        else next.delete('fromDate')
      } else if (value) next.set('toDate', value)
      else next.delete('toDate')
      const range = dateOnlyRangeToIso(values.from, values.to, timeZone)
      if (range.from) next.set('from', range.from)
      else next.delete('from')
      if (range.to) next.set('to', range.to)
      else next.delete('to')
      return next
    }, { replace: true })
  }

  const walletValue = params.get('walletId') ?? 'all'
  const categoryValue = params.get('categoryId') ?? 'all'

  function updateAmount(key, value) {
    if (value && !/^\d+(?:\.\d{0,2})?$/.test(value)) return
    update(key, value)
  }

  return (
    <>
    <Tabs className="mb-3" onValueChange={(value) => update('type', value)} value={type}>
      <TabsList aria-label="Filter by transaction type" className="w-full sm:w-fit">
        {TYPE_OPTIONS.map(([value, label]) => (
          <TabsTrigger className="isolate" key={value} value={value}>
            {type === value && <m.span className="absolute inset-0 z-0 rounded-md bg-background shadow-sm" layoutId="transaction-type-indicator" transition={motionDisabled ? { duration: 0 } : { type: 'spring', stiffness: 420, damping: 34 }} />}
            <span className="relative z-10">{label === 'All types' ? 'All' : label}</span>
          </TabsTrigger>
        ))}
      </TabsList>
    </Tabs>
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
      <label className="space-y-1.5 text-xs font-medium">
        Wallet
        <Select onValueChange={(value) => update('walletId', value)} value={walletValue}>
          <SelectTrigger className="h-10 w-full"><SelectValue placeholder="All wallets" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All wallets</SelectItem>
            {wallets.map((wallet) => <SelectItem key={wallet.id ?? wallet._id} value={wallet.id ?? wallet._id}>{wallet.name}</SelectItem>)}
          </SelectContent>
        </Select>
      </label>
      <label className="space-y-1.5 text-xs font-medium">
        Category
        <Select disabled={type === 'transfer'} onValueChange={(value) => update('categoryId', value)} value={categoryValue}>
          <SelectTrigger className="h-10 w-full"><SelectValue placeholder="All categories" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All categories</SelectItem>
            {categories.map((category) => <SelectItem key={category.id ?? category._id} value={category.id ?? category._id}>{category.icon} {category.name}</SelectItem>)}
          </SelectContent>
        </Select>
      </label>
      <label className="space-y-1.5 text-xs font-medium">
        Date
        <Select onValueChange={(value) => update('datePreset', value)} value={datePreset}>
          <SelectTrigger className="h-10 w-full"><SelectValue /></SelectTrigger>
          <SelectContent>{DATE_OPTIONS.map(([value, label]) => <SelectItem key={value} value={value}>{label}</SelectItem>)}</SelectContent>
        </Select>
      </label>
      {datePreset === 'custom' && (
        <>
          <label className="space-y-1.5 text-xs font-medium">
            From
            <Input aria-label="From date" className="h-10" onChange={(event) => updateCustomDate('from', event.target.value)} type="date" value={params.get('fromDate') ?? ''} />
          </label>
          <label className="space-y-1.5 text-xs font-medium">
            To
            <Input aria-label="To date" className="h-10" onChange={(event) => updateCustomDate('to', event.target.value)} type="date" value={params.get('toDate') ?? ''} />
          </label>
        </>
      )}
      <label className="space-y-1.5 text-xs font-medium">
        Minimum amount (₹)
        <Input aria-label="Minimum amount in rupees" className="h-10" inputMode="decimal" onChange={(event) => updateAmount('minAmount', event.target.value)} placeholder="0.00" value={params.get('minAmount') ?? ''} />
      </label>
      <label className="space-y-1.5 text-xs font-medium">
        Maximum amount (₹)
        <Input aria-label="Maximum amount in rupees" className="h-10" inputMode="decimal" onChange={(event) => updateAmount('maxAmount', event.target.value)} placeholder="0.00" value={params.get('maxAmount') ?? ''} />
      </label>
      <label className="space-y-1.5 text-xs font-medium">
        Tag
        <Input aria-label="Filter by tag" className="h-10" maxLength={30} onChange={(event) => update('tag', event.target.value)} placeholder="e.g. groceries" value={params.get('tag') ?? ''} />
      </label>
    </div>
    </>
  )
}

export function TransactionFilters({ params, setParams, timeZone }) {
  const currentSearch = params.get('q') ?? ''
  const [searchDraft, setSearchDraft] = useState({ source: currentSearch, value: currentSearch })
  const search = searchDraft.source === currentSearch ? searchDraft.value : currentSearch
  const [sheetOpen, setSheetOpen] = useState(false)
  const motionDisabled = useMotionDisabled()

  useEffect(() => {
    const timeout = window.setTimeout(() => {
      setParams((current) => {
        const next = new URLSearchParams(current)
        if (search.trim()) next.set('q', search.trim())
        else next.delete('q')
        return next
      }, { replace: true })
    }, 400)
    return () => window.clearTimeout(timeout)
  }, [search, setParams])

  const activeCount = activeTransactionFilterCount(params)

  function clearAll() {
    setSearchDraft({ source: currentSearch, value: '' })
    setParams((current) => {
      const next = new URLSearchParams(current)
      EMPTY_FILTERS.forEach((key) => next.delete(key))
      next.delete('fromDate')
      next.delete('toDate')
      return next
    }, { replace: true })
  }

  const fields = <FilterFields params={params} setParams={setParams} timeZone={timeZone} />

  return (
    <section className="glass-strong rounded-2xl p-4 sm:p-5" aria-label="Transaction filters">
      <div className="flex flex-col gap-3 sm:flex-row">
        <label className="group relative min-w-0 flex-1 transition-[width] duration-200 ease-out sm:w-64 sm:flex-none focus-within:sm:w-80">
          <Search aria-hidden="true" className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input aria-label="Search transactions" className="h-10 pl-9" maxLength={80} onChange={(event) => setSearchDraft({ source: currentSearch, value: event.target.value })} placeholder="Search merchant or note" type="search" value={search} />
        </label>
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">{activeCount} active</span>
          {activeCount > 0 && <Button onClick={clearAll} size="sm" variant="ghost"><X aria-hidden="true" />Clear all</Button>}
          <div className="sm:hidden">
            <Sheet onOpenChange={setSheetOpen} open={sheetOpen}>
              <SheetTrigger asChild><Button aria-label="Open filters" variant="outline"><Filter aria-hidden="true" />Filters</Button></SheetTrigger>
              <SheetContent className="max-h-[85dvh] overflow-y-auto rounded-t-3xl p-5" side="bottom">
                <SheetHeader className="px-0 pt-1"><SheetTitle>Filters</SheetTitle></SheetHeader>
                {fields}
                <Button className="mt-2 w-full" onClick={() => setSheetOpen(false)}>Done</Button>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
      <div className="mt-4 hidden sm:block">{fields}</div>
      <AnimatePresence initial={false}>
        {activeCount > 0 && (
          <m.div className="mt-3 flex flex-wrap gap-2" layout>
            {filterChips(params).map((chip) => (
              <m.button
                animate={{ opacity: 1, scale: 1, y: 0 }}
                className="inline-flex items-center gap-1.5 rounded-full border border-border/70 bg-accent/70 px-3 py-1.5 text-xs font-medium text-accent-foreground"
                exit={{ opacity: 0, scale: 0.8, y: -4 }}
                initial={{ opacity: 0, scale: 0.8, y: 4 }}
                key={chip.key}
                layout
                onClick={() => removeFilter(chip.key, setParams)}
                transition={motionDisabled ? { duration: 0 } : { type: 'spring', stiffness: 420, damping: 30 }}
                type="button"
              >
                {chip.label}
                <X aria-hidden="true" className="size-3" />
              </m.button>
            ))}
          </m.div>
        )}
      </AnimatePresence>
    </section>
  )
}

function filterChips(params) {
  const chips = []
  const labels = {
    type: { expense: 'Expense', income: 'Income', transfer: 'Transfer' },
    datePreset: { today: 'Today', week: 'This week', month: 'This month', custom: 'Custom dates' },
  }
  for (const key of ['q', 'type', 'walletId', 'categoryId', 'datePreset', 'minAmount', 'maxAmount', 'tag']) {
    const value = params.get(key)
    if (!value || value === 'all' || value === 'none') continue
    const label = key === 'q' ? `Search: ${value}`
      : key === 'type' ? labels.type[value] ?? value
        : key === 'walletId' ? `Wallet: ${value}`
          : key === 'categoryId' ? `Category: ${value}`
            : key === 'datePreset' ? labels.datePreset[value] ?? value
              : key === 'minAmount' ? `Min: ₹${value}`
                : key === 'maxAmount' ? `Max: ₹${value}`
                  : `Tag: ${value}`
    chips.push({ key, label })
  }
  if (params.has('fromDate')) chips.push({ key: 'fromDate', label: `From: ${params.get('fromDate')}` })
  if (params.has('toDate')) chips.push({ key: 'toDate', label: `To: ${params.get('toDate')}` })
  if (!params.has('datePreset') && (params.has('from') || params.has('to'))) chips.push({ key: 'from', label: 'Date range' })
  return chips
}

function removeFilter(key, setParams) {
  setParams((current) => {
    const next = new URLSearchParams(current)
    if (key === 'fromDate' || key === 'toDate' || key === 'from') {
      next.delete('from')
      next.delete('to')
      next.delete('fromDate')
      next.delete('toDate')
      next.delete('datePreset')
    } else {
      next.delete(key)
      if (key === 'datePreset') {
        next.delete('from')
        next.delete('to')
        next.delete('fromDate')
        next.delete('toDate')
      }
    }
    return next
  }, { replace: true })
}

export function transactionFiltersFromParams(params) {
  const filters = {}
  for (const key of ['type', 'walletId', 'categoryId', 'tag', 'q', 'from', 'to']) {
    const value = params.get(key)
    if (value) filters[key] = value
  }
  const minimum = params.get('minAmount')
  const maximum = params.get('maxAmount')
  if (minimum !== null && minimum !== '') {
    const paise = toPaise(minimum)
    if (paise !== null) filters.minAmount = paise
  }
  if (maximum !== null && maximum !== '') {
    const paise = toPaise(maximum)
    if (paise !== null) filters.maxAmount = paise
  }
  return filters
}

export function activeTransactionFilterCount(params) {
  const otherFilters = ['q', 'type', 'walletId', 'categoryId', 'minAmount', 'maxAmount', 'tag']
    .filter((key) => {
      const value = params.get(key)
      return Boolean(value && value !== 'all' && value !== 'none')
    }).length
  return otherFilters + (params.has('datePreset') || params.has('from') || params.has('to') ? 1 : 0)
}
