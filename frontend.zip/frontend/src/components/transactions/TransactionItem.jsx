import { ArrowLeftRight } from 'lucide-react'
import { m } from 'motion/react'
import Amount from '@/components/common/Amount.jsx'
import { formatINR } from '@/lib/money.js'
import { MoreHorizontal, Pencil, Trash2 } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu.jsx'
import { Button } from '@/components/ui/button.jsx'

function formatTransactionTime(value, timeZone = 'Asia/Kolkata') {
  const date = new Date(value)
  if (!Number.isFinite(date.getTime())) return ''

  return new Intl.DateTimeFormat('en-IN', {
    hour: 'numeric',
    minute: '2-digit',
    timeZone,
  }).format(date)
}

function TransactionItem({
  transaction,
  timeZone = 'Asia/Kolkata',
  className = '',
  style,
  onEdit,
  onDelete,
  minimumFractionDigits = 0,
  layout = false,
  highlighted = false,
  isPhone = false,
  motionDisabled = false,
}) {
  const isTransfer = transaction.type === 'transfer'
  const category = transaction.categoryId
  const wallet = transaction.walletId
  const title = isTransfer
    ? transaction.transferDirection === 'in' ? 'Transfer in' : 'Transfer out'
    : transaction.merchant || category?.name || 'Uncategorized'
  const subtitle = [
    !isTransfer && category?.name && transaction.merchant ? category.name : null,
    wallet?.name,
    formatTransactionTime(transaction.txnDate, timeZone),
  ].filter(Boolean).join(' · ')

  return (
    <m.li
      animate={{ opacity: 1, height: 'auto', marginTop: 0 }}
      className={`relative min-w-0 overflow-hidden rounded-2xl ${layout ? '' : 'list-none'} ${className}`}
      exit={{ opacity: 0, height: 0, marginTop: 0, marginBottom: 0 }}
      initial={layout ? { opacity: 0, height: 0 } : false}
      layout={layout ? 'position' : false}
      style={style}
      transition={motionDisabled ? { duration: 0 } : { layout: { duration: 0.22 }, opacity: { duration: 0.16 }, height: { duration: 0.2 } }}
    >
      {onDelete && isPhone && (
        <span className="absolute inset-y-0 right-0 flex w-20 items-center justify-center bg-destructive text-destructive-foreground">
          <Button aria-label={`Delete ${title}`} className="h-full w-full rounded-none text-destructive-foreground hover:bg-destructive/90 hover:text-destructive-foreground" onClick={onDelete} variant="ghost">
            <Trash2 aria-hidden="true" />
            <span className="sr-only">Delete</span>
          </Button>
        </span>
      )}
      <m.div
        animate={{ x: 0 }}
        className={`glass-flat relative flex min-w-0 items-center gap-3 rounded-2xl p-3 sm:p-4 ${highlighted ? 'transaction-highlight' : ''}`}
        drag={isPhone && onDelete ? 'x' : false}
        dragConstraints={{ left: -80, right: 0 }}
        dragElastic={0.08}
        onDragEnd={(_, info) => {
          if (info.offset.x < -55) onDelete?.()
        }}
        whileDrag={isPhone ? { cursor: 'grabbing' } : undefined}
        style={{ touchAction: 'pan-y' }}
      >
        <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-accent text-base text-accent-foreground">
          {isTransfer
            ? <ArrowLeftRight aria-hidden="true" className="size-5" />
            : <span aria-hidden="true">{category?.icon || '📦'}</span>}
        </span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-sm font-semibold">{title}</span>
          <span className="mt-0.5 block truncate text-xs text-muted-foreground">{subtitle || 'Transaction'}</span>
        </span>
        <Amount
          aria-label={`${isTransfer ? 'Transfer' : transaction.type} ${formatINR(transaction.amount, { minimumFractionDigits })}`}
          className="text-sm"
          minimumFractionDigits={minimumFractionDigits}
          type={isTransfer ? 'neutral' : transaction.type}
          value={transaction.amount}
        />
        {(onEdit || onDelete) && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button aria-label={`Actions for ${title}`} size="icon" variant="ghost"><MoreHorizontal aria-hidden="true" /></Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {!isTransfer && onEdit && <DropdownMenuItem onSelect={onEdit}><Pencil aria-hidden="true" />Edit</DropdownMenuItem>}
              {onDelete && <DropdownMenuItem onSelect={onDelete} variant="destructive"><Trash2 aria-hidden="true" />Delete</DropdownMenuItem>}
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </m.div>
    </m.li>
  )
}

export default TransactionItem
