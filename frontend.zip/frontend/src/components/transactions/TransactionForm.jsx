import { useEffect, useMemo, useRef, useState } from 'react'
import { Controller, useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { toast } from 'sonner'
import { m } from 'motion/react'
import { useMotionDisabled } from '@/hooks/useMotionDisabled.js'
import { useCategories } from '@/hooks/useCategories.js'
import { useWallets } from '@/hooks/useWallets.js'
import { getFieldErrors } from '@/lib/errors.js'
import { formatDateTimeLocal, localDateTimeToIso } from '@/lib/transactionDates.js'
import { fromPaise, toPaise } from '@/lib/money.js'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select.jsx'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog.jsx'
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet.jsx'

const paymentMethods = [
  ['cash', 'Cash'],
  ['upi', 'UPI'],
  ['debit_card', 'Debit card'],
  ['credit_card', 'Credit card'],
  ['net_banking', 'Net banking'],
]
const amountPattern = /^\d+(?:\.\d{1,2})?$/

function transactionFormSchema(maxDate) {
  return z.object({
    type: z.enum(['expense', 'income']),
    amount: z.string().trim().regex(amountPattern, 'Enter an amount with up to 2 decimal places')
      .refine((value) => {
        const paise = toPaise(value)
        return paise !== null && paise > 0 && paise <= 10_000_000_000
      }, 'Amount must be greater than zero and within the allowed limit'),
    walletId: z.string().min(1, 'Choose a wallet'),
    categoryId: z.string(),
    merchant: z.string().max(80, 'Merchant must be 80 characters or fewer'),
    note: z.string().max(300, 'Note must be 300 characters or fewer'),
    tagsText: z.string().superRefine((value, context) => {
      const tags = value.split(',').map((tag) => tag.trim()).filter(Boolean)
      if (tags.length > 10) context.addIssue({ code: 'custom', message: 'Use at most 10 tags' })
      if (tags.some((tag) => tag.length > 30)) context.addIssue({ code: 'custom', message: 'Each tag must be 30 characters or fewer' })
    }),
    paymentMethod: z.enum(['cash', 'upi', 'debit_card', 'credit_card', 'net_banking']),
    txnDate: z.string().min(1, 'Choose a date and time')
      .refine((value) => !Number.isNaN(new Date(value).getTime()), 'Enter a valid date and time')
      .refine((value) => value <= maxDate, 'Date cannot be in the future'),
  })
}

function transactionId(transaction) {
  return transaction?.id ?? transaction?._id
}

function initialValues(transaction, timeZone) {
  return {
    type: transaction?.type === 'income' ? 'income' : 'expense',
    amount: transaction ? fromPaise(transaction.amount).toFixed(2) : '',
    walletId: transaction?.walletId?.id ?? transaction?.walletId?._id ?? transaction?.walletId ?? '',
    categoryId: transaction?.categoryId?.id ?? transaction?.categoryId?._id ?? transaction?.categoryId ?? '',
    merchant: transaction?.merchant ?? '',
    note: transaction?.note ?? '',
    tagsText: (transaction?.tags ?? []).join(', '),
    paymentMethod: transaction?.paymentMethod ?? 'cash',
    txnDate: transaction?.txnDate
      ? formatDateTimeLocal(new Date(transaction.txnDate), timeZone)
      : formatDateTimeLocal(new Date(), timeZone),
  }
}

function useIsMobile() {
  const [mobile, setMobile] = useState(() => window.matchMedia?.('(max-width: 639px)').matches ?? false)
  useEffect(() => {
    if (!window.matchMedia) return undefined
    const media = window.matchMedia('(max-width: 639px)')
    const update = () => setMobile(media.matches)
    media.addEventListener('change', update)
    return () => media.removeEventListener('change', update)
  }, [])
  return mobile
}

function TransactionFormBody({ transaction, timeZone, onClose, mutations }) {
  const editing = Boolean(transaction)
  const motionDisabled = useMotionDisabled()
  const [clientId] = useState(() => editing ? undefined : window.crypto.randomUUID())
  const values = useMemo(() => initialValues(transaction, timeZone), [timeZone, transaction])
  const [now] = useState(() => new Date())
  const maxDate = formatDateTimeLocal(now, timeZone)
  const {
    control,
    handleSubmit,
    register,
    setError,
    setValue,
    watch,
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: zodResolver(transactionFormSchema(maxDate)),
    defaultValues: values,
  })
  const type = watch('type')
  const tagsText = watch('tagsText')
  const previousType = useRef(type)
  const { data: walletData, isLoading: walletsLoading } = useWallets()
  const wallets = walletData?.wallets ?? walletData ?? []
  const { data: categories = [], isLoading: categoriesLoading } = useCategories(type)

  useEffect(() => {
    if (previousType.current !== type) {
      setValue('categoryId', '', { shouldDirty: true })
      previousType.current = type
    }
  }, [setValue, type])

  function changedFields(formValues) {
    const tags = formValues.tagsText.split(',').map((tag) => tag.trim()).filter(Boolean)
    const txnDate = localDateTimeToIso(formValues.txnDate, timeZone)
    const payload = {
      amount: toPaise(formValues.amount),
      walletId: formValues.walletId,
      categoryId: formValues.categoryId || null,
      merchant: formValues.merchant.trim(),
      note: formValues.note.trim(),
      tags,
      paymentMethod: formValues.paymentMethod,
      txnDate,
    }
    if (!editing) {
      const createPayload = {
        ...payload,
        type: formValues.type,
        clientId,
        source: 'manual',
      }
      if (!createPayload.categoryId) delete createPayload.categoryId
      return createPayload
    }

    const original = {
      amount: Number(transaction.amount),
      walletId: transaction.walletId?.id ?? transaction.walletId?._id ?? transaction.walletId,
      categoryId: transaction.categoryId?.id ?? transaction.categoryId?._id ?? transaction.categoryId ?? null,
      merchant: transaction.merchant ?? '',
      note: transaction.note ?? '',
      tags: transaction.tags ?? [],
      paymentMethod: transaction.paymentMethod ?? 'cash',
      txnDate: new Date(transaction.txnDate).toISOString(),
    }
    return Object.fromEntries(Object.entries(payload).filter(([key, value]) => {
      if (key === 'tags') return JSON.stringify(value) !== JSON.stringify(original.tags)
      if (key === 'txnDate') return formValues.txnDate !== initialValues(transaction, timeZone).txnDate
      return value !== original[key]
    }))
  }

  function submit(formValues) {
    const payload = changedFields(formValues)
    if (editing && Object.keys(payload).length === 0) {
      onClose()
      return
    }

    const request = editing
      ? mutations.update.mutateAsync({ id: transactionId(transaction), payload })
      : mutations.create.mutateAsync(payload)
    return request.then((response) => {
      if (!editing) toast.success(response?.duplicate ? 'Already saved' : 'Added')
      else toast.success('Transaction updated')
      onClose()
    }, (error) => {
      const fieldErrors = getFieldErrors(error)
      Object.entries(fieldErrors).forEach(([field, message]) => {
        if (['amount', 'walletId', 'categoryId', 'merchant', 'note', 'tags', 'paymentMethod', 'txnDate', 'type'].includes(field)) {
          setError(field === 'tags' ? 'tagsText' : field, { type: 'server', message })
        }
      })
    })
  }

  const tags = tagsText.split(',').map((tag) => tag.trim()).filter(Boolean)
  const fields = (
    <form className="space-y-4" onSubmit={handleSubmit(submit)}>
      {!editing && (
        <div aria-label="Transaction type" className="grid grid-cols-2 gap-2 rounded-xl bg-muted p-1">
          {['expense', 'income'].map((value) => (
            <Button
              aria-pressed={type === value}
              className={type === value ? 'bg-background shadow-sm' : 'text-muted-foreground'}
              key={value}
              onClick={() => setValue('type', value, { shouldDirty: true })}
              type="button"
              variant="ghost"
            >
              {value === 'expense' ? 'Expense' : 'Income'}
            </Button>
          ))}
        </div>
      )}
      {editing && <p className="text-sm font-medium capitalize text-muted-foreground">{type}</p>}
      <div className="space-y-1.5">
        <Label htmlFor="transaction-amount">Amount (₹)</Label>
        <Input aria-invalid={Boolean(errors.amount)} autoFocus inputMode="decimal" id="transaction-amount" max="100000000" pattern="^\d+(\.\d{1,2})?$" placeholder="120.50" {...register('amount')} />
        {errors.amount && <p className="text-xs text-destructive">{errors.amount.message}</p>}
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="space-y-1.5">
          <Label htmlFor="transaction-wallet">Wallet</Label>
          <Controller
            control={control}
            name="walletId"
            render={({ field }) => (
              <Select disabled={walletsLoading} onValueChange={field.onChange} value={field.value}>
                <SelectTrigger aria-invalid={Boolean(errors.walletId)} className="h-10 w-full" id="transaction-wallet"><SelectValue placeholder="Select wallet" /></SelectTrigger>
                <SelectContent>{wallets.map((wallet) => <SelectItem key={wallet.id ?? wallet._id} value={wallet.id ?? wallet._id}>{wallet.name}</SelectItem>)}</SelectContent>
              </Select>
            )}
          />
          {errors.walletId && <p className="text-xs text-destructive">{errors.walletId.message}</p>}
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="transaction-category">Category</Label>
          <Controller
            control={control}
            name="categoryId"
            render={({ field }) => (
              <Select disabled={categoriesLoading} onValueChange={(value) => field.onChange(value === 'none' ? '' : value)} value={field.value || 'none'}>
                <SelectTrigger aria-invalid={Boolean(errors.categoryId)} className="h-10 w-full" id="transaction-category"><SelectValue placeholder="Optional" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No category</SelectItem>
                  {categories.map((category) => <SelectItem key={category.id ?? category._id} value={category.id ?? category._id}>{category.icon} {category.name}</SelectItem>)}
                </SelectContent>
              </Select>
            )}
          />
          {errors.categoryId && <p className="text-xs text-destructive">{errors.categoryId.message}</p>}
        </div>
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="transaction-merchant">Merchant</Label>
        <Input id="transaction-merchant" maxLength={80} {...register('merchant')} />
        {errors.merchant && <p className="text-xs text-destructive">{errors.merchant.message}</p>}
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="transaction-note">Note</Label>
        <Input id="transaction-note" maxLength={300} {...register('note')} />
        {errors.note && <p className="text-xs text-destructive">{errors.note.message}</p>}
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="transaction-tags">Tags (comma separated)</Label>
        <Input id="transaction-tags" maxLength={309} placeholder="groceries, weekend" {...register('tagsText')} />
        {tags.length > 0 && <div className="flex flex-wrap gap-1.5">{tags.map((tag, index) => <span className="rounded-full bg-accent px-2.5 py-1 text-xs text-accent-foreground" key={`${tag}-${index}`}>{tag}</span>)}</div>}
        {errors.tagsText && <p className="text-xs text-destructive">{errors.tagsText.message}</p>}
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="space-y-1.5">
          <Label htmlFor="transaction-payment">Payment method</Label>
          <Controller
            control={control}
            name="paymentMethod"
            render={({ field }) => (
              <Select onValueChange={field.onChange} value={field.value}>
                <SelectTrigger className="h-10 w-full" id="transaction-payment"><SelectValue /></SelectTrigger>
                <SelectContent>{paymentMethods.map(([value, label]) => <SelectItem key={value} value={value}>{label}</SelectItem>)}</SelectContent>
              </Select>
            )}
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="transaction-date">Date and time</Label>
          <Input aria-invalid={Boolean(errors.txnDate)} id="transaction-date" max={maxDate} type="datetime-local" {...register('txnDate')} />
          {errors.txnDate && <p className="text-xs text-destructive">{errors.txnDate.message}</p>}
        </div>
      </div>
      <div className="flex justify-end gap-2 border-t pt-4">
        <Button onClick={onClose} type="button" variant="outline">Cancel</Button>
        <Button disabled={isSubmitting || mutations.create.isPending || mutations.update.isPending} type="submit">
          {editing ? 'Save changes' : 'Add transaction'}
        </Button>
      </div>
    </form>
  )

  const mobile = useIsMobile()
  if (mobile) {
    return (
      <Sheet onOpenChange={(open) => { if (!open) onClose() }} open>
        <SheetContent className="max-h-[92dvh] overflow-y-auto rounded-t-3xl p-5" side="bottom">
          <m.div
            animate={{ opacity: 1, y: 0 }}
            initial={motionDisabled ? false : { opacity: 0, y: 24 }}
            transition={motionDisabled ? { duration: 0 } : { type: 'spring', stiffness: 360, damping: 30 }}
          >
            <SheetHeader className="px-0 pt-1">
              <SheetTitle>{editing ? 'Edit transaction' : 'Add transaction'}</SheetTitle>
              <SheetDescription>Enter the details for this transaction.</SheetDescription>
            </SheetHeader>
            {fields}
          </m.div>
        </SheetContent>
      </Sheet>
    )
  }
  return (
    <Dialog onOpenChange={(open) => { if (!open) onClose() }} open>
      <DialogContent className="max-h-[90vh] max-w-xl overflow-y-auto">
        <m.div
          animate={{ opacity: 1, scale: 1, y: 0 }}
          initial={motionDisabled ? false : { opacity: 0, scale: 0.97, y: 12 }}
          transition={motionDisabled ? { duration: 0 } : { type: 'spring', stiffness: 380, damping: 30 }}
        >
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit transaction' : 'Add transaction'}</DialogTitle>
            <DialogDescription>Enter the details for this transaction.</DialogDescription>
          </DialogHeader>
          {fields}
        </m.div>
      </DialogContent>
    </Dialog>
  )
}

function TransactionForm(props) {
  return <TransactionFormBody key={props.transaction ? transactionId(props.transaction) : 'new'} {...props} />
}

export default TransactionForm
