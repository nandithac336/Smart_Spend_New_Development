import { formatINR } from '@/lib/money.js'
import CountUp from '@/components/motion/CountUp.jsx'

const amountStyles = {
  income: { sign: '+', className: 'text-income' },
  expense: { sign: '−', className: 'text-expense' },
  neutral: { sign: '', className: 'text-foreground' },
}

function Amount({
  value,
  type = 'neutral',
  className = '',
  animated = false,
  minimumFractionDigits = 0,
  ...props
}) {
  const style = amountStyles[type] ?? amountStyles.neutral
  const absoluteAmount = Math.abs(Number(value))

  return (
    <span className={`tabular whitespace-nowrap font-semibold ${style.className} ${className}`} {...props}>
      {animated
        ? <CountUp aria-hidden="true" currency prefix={style.sign} value={absoluteAmount} />
        : `${style.sign}${formatINR(absoluteAmount, { minimumFractionDigits })}`}
    </span>
  )
}

export default Amount
