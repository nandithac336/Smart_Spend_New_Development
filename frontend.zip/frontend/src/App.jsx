import { AuthProvider } from './context/AuthContext.jsx'
import PageTransition from './components/motion/PageTransition.jsx'
import ProtectedRoute from './components/layout/ProtectedRoute.jsx'
import PublicOnlyRoute from './components/layout/PublicOnlyRoute.jsx'
import FullScreenLoader from './components/layout/FullScreenLoader.jsx'
import NotFound from './components/layout/NotFound.jsx'
import AppShell from './components/layout/AppShell.jsx'

export const router = [
  {
    HydrateFallback: FullScreenLoader,
    element: (
      <AuthProvider>
        <PageTransition />
      </AuthProvider>
    ),
    children: [
      {
        path: '/',
        lazy: async () => ({
          Component: (await import('./pages/Landing.jsx')).default,
        }),
      },
      {
        element: <PublicOnlyRoute />,
        children: [
          {
            path: '/login',
            lazy: async () => ({
              Component: (await import('./pages/Login.jsx')).default,
            }),
          },
          {
            path: '/register',
            lazy: async () => ({
              Component: (await import('./pages/Register.jsx')).default,
            }),
          },
        ],
      },
      {
        element: <ProtectedRoute />,
        children: [
          {
            element: <AppShell />,
            children: [
              {
                path: '/dashboard',
                lazy: async () => ({
                  Component: (await import('./pages/Dashboard.jsx')).default,
                }),
              },
              {
                path: '/transactions',
                lazy: async () => ({
                  Component: (await import('./pages/Transactions.jsx')).default,
                }),
              },
              {
                path: '/wallets',
                lazy: async () => ({
                  Component: (await import('./pages/Wallets.jsx')).default,
                }),
              },
              {
                path: '/settings',
                lazy: async () => ({
                  Component: (await import('./pages/Settings.jsx')).default,
                }),
              },
            ],
          },
        ],
      },
      { path: '*', element: <NotFound /> },
    ],
  },
]
