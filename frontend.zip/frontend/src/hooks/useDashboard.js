import { useQuery } from '@tanstack/react-query'
import { getDashboard } from '@/services/dashboardApi.js'

export function useDashboard() {
  return useQuery({
    queryKey: ['dashboard'],
    queryFn: getDashboard,
  })
}
