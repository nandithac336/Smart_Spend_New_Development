import { useMutation, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import {
  createTransaction,
  deleteTransaction,
  restoreTransaction,
  updateTransaction,
} from '@/services/transactionApi.js'
import { getErrorMessage } from '@/lib/errors.js'

export function useTransactionMutations() {
  const queryClient = useQueryClient()

  async function invalidateTransactionData() {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ['transactions'] }),
      queryClient.invalidateQueries({ queryKey: ['wallets'] }),
      queryClient.invalidateQueries({ queryKey: ['dashboard'] }),
    ])
  }

  const options = {
    onSuccess: invalidateTransactionData,
    onError: (error) => toast.error(getErrorMessage(error, 'Could not save transaction.')),
  }

  return {
    create: useMutation({ mutationFn: createTransaction, ...options }),
    update: useMutation({
      mutationFn: ({ id, payload }) => updateTransaction(id, payload),
      ...options,
    }),
    remove: useMutation({ mutationFn: deleteTransaction, ...options }),
    restore: useMutation({ mutationFn: restoreTransaction, ...options }),
  }
}
