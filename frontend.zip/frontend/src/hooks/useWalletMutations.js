import { useMutation, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import {
  archiveWallet,
  createWallet,
  transferBetweenWallets,
  updateWallet,
} from '@/services/walletApi.js'
import { getErrorMessage } from '@/lib/errors.js'

export function useWalletMutations() {
  const queryClient = useQueryClient()

  async function invalidateWalletData() {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ['wallets'] }),
      queryClient.invalidateQueries({ queryKey: ['transactions'] }),
      queryClient.invalidateQueries({ queryKey: ['dashboard'] }),
    ])
  }

  const options = {
    onSuccess: invalidateWalletData,
    onError: (error) => toast.error(getErrorMessage(error, 'Could not update wallets.')),
  }

  return {
    create: useMutation({ mutationFn: createWallet, ...options }),
    update: useMutation({
      mutationFn: ({ id, payload }) => updateWallet(id, payload),
      ...options,
    }),
    archive: useMutation({ mutationFn: archiveWallet, ...options }),
    transfer: useMutation({ mutationFn: transferBetweenWallets, ...options }),
  }
}
