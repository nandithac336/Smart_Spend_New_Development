import { createElement } from 'react'
import { act, renderHook } from '@testing-library/react'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { toast } from 'sonner'
import {
  createTransaction,
  deleteTransaction,
  restoreTransaction,
  updateTransaction,
} from '@/services/transactionApi.js'
import { useTransactionMutations } from './useTransactionMutations.js'

vi.mock('sonner', () => ({ toast: { error: vi.fn() } }))
vi.mock('@/services/transactionApi.js', () => ({
  createTransaction: vi.fn(),
  deleteTransaction: vi.fn(),
  restoreTransaction: vi.fn(),
  updateTransaction: vi.fn(),
}))

describe('useTransactionMutations', () => {
  let queryClient
  let invalidate
  let wrapper

  beforeEach(() => {
    vi.clearAllMocks()
    queryClient = new QueryClient()
    invalidate = vi.spyOn(queryClient, 'invalidateQueries').mockResolvedValue()
    wrapper = ({ children }) => createElement(QueryClientProvider, { client: queryClient }, children)
  })

  it('invalidates transactions, wallets, and dashboard after every mutation', async () => {
    createTransaction.mockResolvedValue({})
    updateTransaction.mockResolvedValue({})
    deleteTransaction.mockResolvedValue({})
    restoreTransaction.mockResolvedValue({})
    const { result } = renderHook(() => useTransactionMutations(), { wrapper })
    const calls = [
      () => result.current.create.mutateAsync({}),
      () => result.current.update.mutateAsync({ id: 'id', payload: {} }),
      () => result.current.remove.mutateAsync('id'),
      () => result.current.restore.mutateAsync('id'),
    ]

    for (const run of calls) {
      await act(run)
    }

    expect(invalidate).toHaveBeenCalledTimes(12)
    expect(invalidate.mock.calls.map(([options]) => options.queryKey)).toEqual([
      ['transactions'], ['wallets'], ['dashboard'],
      ['transactions'], ['wallets'], ['dashboard'],
      ['transactions'], ['wallets'], ['dashboard'],
      ['transactions'], ['wallets'], ['dashboard'],
    ])
  })

  it('shows the API error message in a toast when a mutation fails', async () => {
    createTransaction.mockRejectedValue({
      response: { data: { error: { message: 'Wallet not found' } } },
    })
    const { result } = renderHook(() => useTransactionMutations(), { wrapper })

    await act(async () => {
      await expect(result.current.create.mutateAsync({})).rejects.toMatchObject({
        response: { data: { error: { message: 'Wallet not found' } } },
      })
    })

    expect(toast.error).toHaveBeenCalledWith('Wallet not found')
  })
})
