import { useState } from 'react'
import { AnimatePresence, m } from 'motion/react'
import {
  Banknote,
  CreditCard,
  Landmark,
  Plus,
  Smartphone,
  Wallet as WalletIcon,
  ArrowLeftRight,
  Pencil,
  Archive,
} from 'lucide-react'
import EmptyState from '@/components/common/EmptyState.jsx'
import ErrorState from '@/components/common/ErrorState.jsx'
import PageHeader from '@/components/common/PageHeader.jsx'
import TransferForm from '@/components/wallets/TransferForm.jsx'
import WalletForm from '@/components/wallets/WalletForm.jsx'
import { AlertDialog, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog.jsx'
import { Button } from '@/components/ui/button.jsx'
import { useWalletMutations } from '@/hooks/useWalletMutations.js'
import { useMotionDisabled } from '@/hooks/useMotionDisabled.js'
import { useWallets } from '@/hooks/useWallets.js'
import CountUp from '@/components/motion/CountUp.jsx'

const walletTypes = {
  cash: { label: 'Cash', Icon: Banknote, style: 'bg-emerald-500/10 text-emerald-600', edge: 'before:bg-emerald-500/70', glow: 'shadow-emerald-500/10' },
  bank: { label: 'Bank', Icon: Landmark, style: 'bg-blue-500/10 text-blue-600', edge: 'before:bg-blue-500/70', glow: 'shadow-blue-500/10' },
  upi: { label: 'UPI', Icon: Smartphone, style: 'bg-violet-500/10 text-violet-600', edge: 'before:bg-violet-500/70', glow: 'shadow-violet-500/10' },
  card: { label: 'Card', Icon: CreditCard, style: 'bg-amber-500/10 text-amber-600', edge: 'before:bg-amber-500/70', glow: 'shadow-amber-500/10' },
}

function walletId(wallet) {
  return wallet.id ?? wallet._id
}

function WalletCard({ wallet, onEdit, onArchive, motionDisabled }) {
  const { label, Icon, style, edge, glow } = walletTypes[wallet.type] ?? {
    label: wallet.type,
    Icon: WalletIcon,
    style: 'bg-primary/10 text-primary',
    edge: 'before:bg-primary/70',
    glow: 'shadow-primary/10',
  }
  const isDefault = Boolean(wallet.isDefault)

  return (
    <m.article
      className={`glass-strong relative overflow-hidden rounded-2xl p-5 shadow-lg before:absolute before:inset-y-4 before:left-0 before:w-1 before:rounded-r-full ${edge} ${glow} sm:p-6`}
      exit={motionDisabled ? { opacity: 0 } : { opacity: 0, height: 0, margin: 0, paddingTop: 0, paddingBottom: 0 }}
      layout
      initial={motionDisabled ? false : 'hidden'}
      variants={{
        hidden: { opacity: 0, y: 14, scale: 0.98 },
        visible: { opacity: 1, y: 0, scale: 1 },
      }}
      transition={motionDisabled ? { duration: 0 } : { type: 'spring', stiffness: 360, damping: 30 }}
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex min-w-0 items-center gap-3">
          <span className={`flex size-11 shrink-0 items-center justify-center rounded-xl ${style}`}>
            <Icon aria-hidden="true" className="size-5" />
          </span>
          <div className="min-w-0">
            <h2 className="truncate font-semibold">{wallet.name}</h2>
            <p className="mt-0.5 text-sm text-muted-foreground">{label}</p>
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-1">
          {isDefault && <span className="mr-1 rounded-full bg-primary/10 px-2.5 py-1 text-xs font-medium text-primary">Default</span>}
          <Button aria-label={`Edit ${wallet.name}`} onClick={() => onEdit(wallet)} size="icon" variant="ghost">
            <Pencil aria-hidden="true" />
          </Button>
          {!isDefault && (
            <Button aria-label={`Archive ${wallet.name}`} onClick={() => onArchive(wallet)} size="icon" variant="ghost">
              <Archive aria-hidden="true" />
            </Button>
          )}
        </div>
      </div>
      <div className="mt-6 border-t border-border/60 pt-4">
        <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Balance</p>
        <p className="mt-1 text-2xl font-bold tracking-tight">
          <CountUp currency value={wallet.balance ?? 0} />
        </p>
      </div>
    </m.article>
  )
}

function Wallets() {
  const { data: walletData, isLoading, isError, refetch } = useWallets()
  const motionDisabled = useMotionDisabled()
  const wallets = walletData?.wallets ?? []
  const totalBalance = walletData?.totalBalance
  const mutations = useWalletMutations()
  const [transferBalanceSnapshot, setTransferBalanceSnapshot] = useState(null)
  const [isAdding, setIsAdding] = useState(false)
  const [isTransferring, setIsTransferring] = useState(false)
  const [editingWallet, setEditingWallet] = useState(null)
  const [archivingWallet, setArchivingWallet] = useState(null)
  const displayedWallets = transferBalanceSnapshot
    ? wallets.map((wallet) => ({
      ...wallet,
      balance: transferBalanceSnapshot.balances.get(walletId(wallet)) ?? wallet.balance,
    }))
    : wallets
  const displayedTotalBalance = transferBalanceSnapshot?.totalBalance ?? totalBalance

  function openTransfer() {
    setTransferBalanceSnapshot({
      totalBalance,
      balances: new Map(wallets.map((wallet) => [walletId(wallet), wallet.balance])),
    })
    setIsTransferring(true)
  }

  function archiveSelectedWallet() {
    if (!archivingWallet) return
    mutations.archive.mutate(walletId(archivingWallet), {
      onSuccess: () => setArchivingWallet(null),
    })
  }

  return (
    <>
      <PageHeader
        action={
          <div className="flex flex-wrap gap-2">
            <Button onClick={openTransfer} variant="outline">
              <ArrowLeftRight aria-hidden="true" />
              Transfer money
            </Button>
            <Button onClick={() => setIsAdding(true)}>
              <Plus aria-hidden="true" />
              Add wallet
            </Button>
          </div>
        }
        description="Keep cash, UPI and other balances together."
        eyebrow="Your accounts"
        title="Wallets"
      />

      <section aria-label="Total balance" className="glass-strong mb-5 rounded-2xl p-5 sm:mb-6 sm:p-6">
        <p className="text-sm font-medium text-muted-foreground">Total balance</p>
        {isLoading ? (
          <div aria-label="Loading total balance" className="mt-3 h-9 w-40 animate-pulse rounded-lg bg-muted" />
        ) : (
          <p className="mt-2 text-3xl font-bold tracking-tight sm:text-4xl">
            {isError ? '—' : <CountUp currency value={displayedTotalBalance ?? 0} />}
          </p>
        )}
      </section>
      <p className="glass-flat mb-6 flex items-start gap-2 rounded-xl px-4 py-3 text-sm text-muted-foreground">
        <ArrowLeftRight aria-hidden="true" className="mt-0.5 size-4 shrink-0" />
        Transfers are not counted as spending.
      </p>

      {isLoading ? (
        <div aria-label="Loading wallets" className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 3 }, (_, index) => (
            <div className="glass-flat h-44 animate-pulse rounded-2xl" key={index} />
          ))}
        </div>
      ) : isError ? (
        <ErrorState onRetry={() => refetch()} title="Could not load wallets" />
      ) : wallets.length === 0 ? (
        <EmptyState
          action={<Button onClick={() => setIsAdding(true)}><Plus aria-hidden="true" />Add wallet</Button>}
          description="Add a wallet to keep your balances organized."
          icon={WalletIcon}
          title="No wallets yet"
        />
      ) : (
        <AnimatePresence initial={!motionDisabled}>
          <m.div
            animate="visible"
            className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3"
            initial={motionDisabled ? false : 'hidden'}
            layout
            variants={{ hidden: {}, visible: { transition: { staggerChildren: motionDisabled ? 0 : 0.07 } } }}
          >
            {displayedWallets.map((wallet) => (
              <WalletCard
                key={walletId(wallet)}
                motionDisabled={motionDisabled}
                onArchive={setArchivingWallet}
                onEdit={setEditingWallet}
                wallet={wallet}
              />
            ))}
          </m.div>
        </AnimatePresence>
      )}

      {isAdding && <WalletForm mutations={mutations} onClose={() => setIsAdding(false)} />}
      {editingWallet && <WalletForm key={walletId(editingWallet)} mutations={mutations} onClose={() => setEditingWallet(null)} wallet={editingWallet} />}
      {isTransferring && (
        <TransferForm
          mutations={mutations}
          onClose={() => {
            setIsTransferring(false)
            setTransferBalanceSnapshot(null)
          }}
          onTransferAnimationComplete={() => setTransferBalanceSnapshot(null)}
          wallets={wallets}
        />
      )}

      <AlertDialog onOpenChange={(open) => { if (!open && !mutations.archive.isPending) setArchivingWallet(null) }} open={Boolean(archivingWallet)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Archive this wallet?</AlertDialogTitle>
            <AlertDialogDescription>
              {archivingWallet && `“${archivingWallet.name}” will be removed from your wallet list.`}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={mutations.archive.isPending}>Cancel</AlertDialogCancel>
            <Button disabled={mutations.archive.isPending} onClick={archiveSelectedWallet} variant="destructive">
              {mutations.archive.isPending ? 'Archiving…' : 'Archive wallet'}
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}

export default Wallets
