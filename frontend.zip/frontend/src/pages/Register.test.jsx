import { cleanup, render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { QueryClientProvider } from '@tanstack/react-query'
import { MemoryRouter, Route, Routes } from 'react-router-dom'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { AuthProvider } from '@/context/AuthContext.jsx'
import { queryClient } from '@/lib/queryClient.js'
import { clearTokens } from '@/services/tokenStorage.js'
import Register from './Register.jsx'

vi.mock('@/services/authApi.js', () => ({
  getMe: vi.fn(),
  login: vi.fn(),
  register: vi.fn(),
  logout: vi.fn(),
}))

import { register } from '@/services/authApi.js'

describe('Register', () => {
  beforeEach(() => {
    cleanup()
    clearTokens()
    queryClient.clear()
    vi.clearAllMocks()
  })

  it('validates password length and letter/number requirements', async () => {
    const user = userEvent.setup()

    render(
      <QueryClientProvider client={queryClient}>
        <MemoryRouter initialEntries={['/register']}>
          <AuthProvider>
            <Routes><Route path="/register" element={<Register />} /></Routes>
          </AuthProvider>
        </MemoryRouter>
      </QueryClientProvider>,
    )

    await user.type(screen.getByLabelText('Name'), 'Alex Example')
    await user.type(screen.getByLabelText('Email'), 'alex@example.com')
    await user.type(screen.getByLabelText('Password'), 'abcdefgh')
    await user.click(screen.getByRole('button', { name: 'Continue' }))

    expect(await screen.findByText('Password must contain a letter and a number')).toBeInTheDocument()
    expect(register).not.toHaveBeenCalled()
  })

  it('submits once from step two and returns to email after a duplicate-email response', async () => {
    register.mockRejectedValue({
      response: {
        status: 409,
        data: { error: { message: 'Email already exists' } },
      },
    })
    const user = userEvent.setup()

    render(
      <QueryClientProvider client={queryClient}>
        <MemoryRouter initialEntries={['/register']}>
          <AuthProvider>
            <Routes><Route path="/register" element={<Register />} /></Routes>
          </AuthProvider>
        </MemoryRouter>
      </QueryClientProvider>,
    )

    await user.type(screen.getByLabelText('Name'), 'Alex Example')
    await user.type(screen.getByLabelText('Email'), 'alex@example.com')
    await user.type(screen.getByLabelText('Password'), 'strongpass123')
    await user.click(screen.getByRole('button', { name: 'Continue' }))
    await user.click(await screen.findByRole('button', { name: 'Create account' }))

    await waitFor(() => expect(register).toHaveBeenCalledTimes(1))
    expect(register).toHaveBeenCalledWith(expect.objectContaining({
      name: 'Alex Example',
      email: 'alex@example.com',
      password: 'strongpass123',
      userType: 'other',
    }))
    expect(await screen.findByText('Email already exists')).toBeInTheDocument()
    expect(screen.getByText('Step 1 of 2')).toBeInTheDocument()
  })
})
