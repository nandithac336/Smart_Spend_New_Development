import { useEffect, useMemo, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { ArrowRight, CalendarDays, CalendarRange, TrendingUp, Wallet as WalletIcon } from 'lucide-react'
import { useAuth } from '@/hooks/useAuth.js'
import { useDashboard } from '@/hooks/useDashboard.js'
import Amount from '@/components/common/Amount.jsx'
import EmptyState from '@/components/common/EmptyState.jsx'
import ErrorState from '@/components/common/ErrorState.jsx'
import ListSkeleton from '@/components/common/ListSkeleton.jsx'
import TransactionItem from '@/components/transactions/TransactionItem.jsx'

function formatToday(timeZone) {
  return new Intl.DateTimeFormat('en-IN', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    timeZone,
  }).format(new Date())
}

const DASHBOARD_ENTRANCE_KEY = 'smart-spend-dashboard-entrance-seen'

function StatCard({ label, value, type = 'neutral', secondary, icon: Icon, animated = false, hero = false, delay = 70 }) {
  return (
    <section
      className={`dashboard-enter-item min-w-0 rounded-2xl p-4 sm:p-5 ${hero ? 'dashboard-balance-hero' : 'glass-strong glass-card-lift'}`}
      style={{ '--dashboard-delay': `${delay}ms` }}
    >
      <div className="flex items-center gap-2 text-muted-foreground">
        {Icon && <Icon aria-hidden="true" className="size-4 shrink-0" />}
        <p className="text-xs font-medium sm:text-sm">{label}</p>
      </div>
      <Amount animated={animated} className={`${hero ? 'mt-4 block text-3xl sm:text-4xl' : 'mt-3 block truncate text-lg sm:text-xl'}`} type={type} value={value} />
      {secondary && <div className="mt-2 text-xs text-muted-foreground">{secondary}</div>}
    </section>
  )
}

function Dashboard() {
  const { user } = useAuth()
  const { data, isPending, isError, refetch } = useDashboard()
  const [animateEntrance] = useState(() => {
    try {
      return window.sessionStorage.getItem(DASHBOARD_ENTRANCE_KEY) !== 'true'
    } catch (error) {
      console.error('Could not read the dashboard entrance state.', error)
      return false
    }
  })
  const [highlightedTransactionIds, setHighlightedTransactionIds] = useState(() => new Set())
  const previousTransactionIds = useRef(null)
  const timezone = data?.period?.timezone || user?.timezone || 'Asia/Kolkata'
  const firstName = user?.name?.trim().split(/\s+/)[0] || 'there'
  const maxCategoryTotal = useMemo(
    () => Math.max(0, ...(data?.topCategories ?? []).map((category) => Number(category.total) || 0)),
    [data?.topCategories],
  )

  useEffect(() => {
    if (isPending || !data || !animateEntrance) return
    try {
      window.sessionStorage.setItem(DASHBOARD_ENTRANCE_KEY, 'true')
    } catch (error) {
      console.error('Could not save the dashboard entrance state.', error)
    }
  }, [animateEntrance, data, isPending])

  useEffect(() => {
    if (!data || isPending) return
    const recent = data.recent ?? []
    const ids = recent.map((transaction) => transaction.id ?? transaction._id).filter(Boolean)
    if (previousTransactionIds.current === null) {
      previousTransactionIds.current = new Set(ids)
      return
    }

    const previousIds = previousTransactionIds.current
    previousTransactionIds.current = new Set(ids)
    const newIds = ids.filter((id) => !previousIds.has(id))
    if (newIds.length > 0) {
      setHighlightedTransactionIds((current) => new Set([...current, ...newIds]))
    }
  }, [data, isPending])

  function openQuickAdd() {
    window.dispatchEvent(new Event('smart-spend:open-quick-add'))
  }

  if (isPending) {
    return (
      <div className="space-y-8" aria-busy="true">
        <div className="space-y-2">
          <div className="skeleton-shimmer h-3 w-32 rounded-full" />
          <div className="skeleton-shimmer h-8 w-56 rounded-full" />
        </div>
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          {Array.from({ length: 4 }, (_, index) => (
            <div className="glass-strong h-28 rounded-2xl p-4" key={index}>
              <div className="skeleton-shimmer h-3 w-2/3 rounded-full" />
              <div className="skeleton-shimmer mt-5 h-6 w-4/5 rounded-full" />
            </div>
          ))}
        </div>
        <ListSkeleton count={3} />
      </div>
    )
  }

  if (isError || !data) {
    return (
      <ErrorState
        description="Your dashboard couldn’t be loaded. Check your connection and try again."
        onRetry={() => refetch()}
        title="Couldn’t load dashboard"
      />
    )
  }

  const monthNet = Number.isFinite(Number(data.monthNet))
    ? Number(data.monthNet)
    : Number(data.monthIncome || 0) - Number(data.monthSpent || 0)
  const hasTransactions = Array.isArray(data.recent) && data.recent.length > 0

  return (
    <div className={`space-y-8 sm:space-y-10 ${animateEntrance ? 'dashboard-entrance' : ''}`}>
      <header>
        <p className="text-sm font-medium text-primary">{formatToday(timezone)}</p>
        <h1 className="mt-2 text-2xl font-bold tracking-tight sm:text-3xl">Good day, {firstName}</h1>
        <p className="mt-1 text-sm text-muted-foreground">Here’s how your money is looking.</p>
      </header>

      <section aria-label="Spending overview" className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-3">
        <div className="col-span-2 lg:col-span-3">
          <StatCard animated={animateEntrance} delay={70} hero icon={WalletIcon} label="Total balance" value={data.totalBalance ?? 0} />
        </div>
        <StatCard animated={animateEntrance} delay={140} icon={CalendarDays} label="Today’s spend" type="expense" value={data.todaySpent ?? 0} />
        <StatCard animated={animateEntrance} delay={200} icon={CalendarRange} label="This month’s spend" type="expense" value={data.monthSpent ?? 0} />
        <StatCard
          animated={animateEntrance}
          delay={260}
          label="This month’s income"
          icon={TrendingUp}
          secondary={(
            <span>
              Net this month <Amount animated={animateEntrance} className="ml-1 text-xs" type={monthNet > 0 ? 'income' : monthNet < 0 ? 'expense' : 'neutral'} value={monthNet} />
            </span>
          )}
          type="income"
          value={data.monthIncome ?? 0}
        />
      </section>

      {(data.wallets ?? []).length > 0 && (
        <section aria-labelledby="wallets-heading">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-base font-semibold" id="wallets-heading">Your wallets</h2>
            <Link className="text-sm font-medium text-primary hover:underline" to="/wallets">All wallets</Link>
          </div>
          <div className="-mx-4 flex snap-x snap-mandatory gap-3 overflow-x-auto px-4 pb-2 sm:-mx-6 sm:px-6 lg:mx-0 lg:snap-none lg:px-0">
            {data.wallets.map((wallet, index) => (
              <article
                className="dashboard-enter-item wallet-tilt glass min-w-44 snap-start rounded-2xl p-4 sm:min-w-52"
                key={wallet.id ?? wallet._id}
                style={{ '--dashboard-delay': `${Math.min(index, 5) * 60}ms` }}
              >
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <WalletIcon aria-hidden="true" className="size-4" />
                  <span className="truncate">{wallet.name}</span>
                </div>
                <Amount className="mt-3 block text-lg" value={wallet.balance ?? 0} />
              </article>
            ))}
          </div>
        </section>
      )}

      {(data.topCategories ?? []).length > 0 && (
        <section aria-labelledby="categories-heading" className="dashboard-enter-item glass-strong rounded-2xl p-4 sm:p-5" style={{ '--dashboard-delay': '330ms' }}>
          <h2 className="mb-4 text-base font-semibold" id="categories-heading">Top categories this month</h2>
          <ul className="space-y-4">
            {data.topCategories.map((category) => {
              const total = Number(category.total) || 0
              const width = maxCategoryTotal > 0 ? `${Math.max(4, (total / maxCategoryTotal) * 100)}%` : '0%'
              const percentage = maxCategoryTotal > 0 ? Math.round((total / maxCategoryTotal) * 100) : 0
              return (
                <li className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-x-3 gap-y-2" key={category.categoryId ?? category.name}>
                  <span aria-hidden="true" className="flex size-9 items-center justify-center rounded-xl bg-accent text-accent-foreground">{category.icon || '📦'}</span>
                  <span className="min-w-0 truncate text-sm font-medium">{category.name}</span>
                  <Amount className="text-sm" type="expense" value={total} />
                  <span className="col-start-2 col-end-4 flex items-center gap-2">
                    <span aria-hidden="true" className="h-1.5 min-w-0 flex-1 overflow-hidden rounded-full bg-muted">
                      <span className={`category-bar-fill ${animateEntrance ? 'category-bar-animate' : ''} block h-full rounded-full bg-primary`} style={{ width }} />
                    </span>
                    <span className={animateEntrance ? 'category-percent-animate text-xs text-muted-foreground' : 'text-xs text-muted-foreground'}>{percentage}%</span>
                  </span>
                </li>
              )
            })}
          </ul>
        </section>
      )}

      <section aria-labelledby="recent-heading">
        <div className="mb-3 flex items-center justify-between gap-3">
          <h2 className="text-base font-semibold" id="recent-heading">Recent transactions</h2>
          {hasTransactions && (
            <Link className="inline-flex items-center gap-1 text-sm font-medium text-primary hover:underline" to="/transactions">
              View all <ArrowRight aria-hidden="true" className="size-4" />
            </Link>
          )}
        </div>
        {hasTransactions ? (
          <ul className="space-y-2">
            {data.recent.map((transaction, index) => (
              <TransactionItem
                className={`${animateEntrance ? 'dashboard-enter-item' : ''} ${highlightedTransactionIds.has(transaction.id ?? transaction._id) ? 'transaction-highlight' : ''}`}
                key={transaction.id ?? transaction._id}
                style={{ '--dashboard-delay': `${350 + Math.min(index, 5) * 55}ms` }}
                timeZone={timezone}
                transaction={transaction}
              />
            ))}
          </ul>
        ) : (
          <EmptyState
            className={animateEntrance ? 'dashboard-enter-item' : ''}
            illustration={(
              <svg aria-hidden="true" className="empty-jar-illustration mb-4 size-24 overflow-visible text-primary" fill="none" viewBox="0 0 96 96">
                <path d="M35 38h26l-2.5 39h-21L35 38Z" className="jar-body" />
                <path d="M32 37h32v7H32zM39 31h18v6H39z" className="jar-rim" />
                <path d="M43 58c3-4 7-4 10 0" className="jar-smile" />
                <circle className="empty-jar-coin" cx="48" cy="18" r="7" />
                <path d="M45 18h6M48 15v6" className="coin-mark" />
                <path d="M28 80h40" className="jar-ground" />
              </svg>
            )}
            action={(
              <button className="rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90" onClick={openQuickAdd} type="button">
                Add your first expense
              </button>
            )}
            description="Your spending and income activity will show up here."
            title="No transactions yet"
          />
        )}
      </section>
    </div>
  )
}

export default Dashboard
