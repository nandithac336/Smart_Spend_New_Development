import { fireEvent, render, screen, waitFor } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import Dashboard from './Dashboard.jsx'

vi.mock('@/hooks/useAuth.js', () => ({
  useAuth: () => ({ user: { name: 'Asha Rao', timezone: 'Asia/Kolkata' } }),
}))

vi.mock('@/hooks/useDashboard.js', () => ({
  useDashboard: vi.fn(),
}))

import { useDashboard } from '@/hooks/useDashboard.js'

describe('Dashboard', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    window.sessionStorage.removeItem('smart-spend-dashboard-entrance-seen')
  })

  it('renders totals from the dashboard API without counting transfers as income or spend', async () => {
    useDashboard.mockReturnValue({
      data: {
        totalBalance: 254000,
        todaySpent: 4000,
        monthSpent: 8600,
        monthIncome: 30000,
        monthNet: 21400,
        period: { timezone: 'Asia/Kolkata' },
        wallets: [{ id: 'cash', name: 'Cash', balance: 250000 }],
        topCategories: [{ categoryId: 'food', name: 'Food', icon: '🍽️', total: 8600, count: 1 }],
        recent: [
          {
            id: 'transfer',
            type: 'transfer',
            transferDirection: 'in',
            amount: 50000,
            txnDate: '2026-10-19T10:00:00.000Z',
            walletId: { name: 'Cash' },
          },
          {
            id: 'expense',
            type: 'expense',
            amount: 8600,
            txnDate: '2026-10-19T09:00:00.000Z',
            categoryId: { name: 'Food', icon: '🍽️' },
            walletId: { name: 'Cash' },
          },
        ],
      },
      isPending: false,
      isError: false,
      refetch: vi.fn(),
    })

    const { container, unmount } = render(<MemoryRouter><Dashboard /></MemoryRouter>)

    expect(container.querySelector('.dashboard-entrance')).toBeInTheDocument()
    expect(window.sessionStorage.getItem('smart-spend-dashboard-entrance-seen')).toBe('true')
    expect(screen.getByRole('heading', { name: 'Good day, Asha' })).toBeInTheDocument()
    await waitFor(() => {
      expect(screen.getByText('₹2,540')).toBeInTheDocument()
      expect(screen.getByText('−₹40')).toBeInTheDocument()
      expect(screen.getAllByText('−₹86')).toHaveLength(3)
      expect(screen.getByText('+₹300')).toBeInTheDocument()
    }, { timeout: 2000 })
    expect(screen.getByText('Net this month')).toBeInTheDocument()
    expect(screen.getByText('Transfer in')).toBeInTheDocument()
    expect(screen.getByLabelText('Transfer ₹500')).toBeInTheDocument()
    expect(screen.getByRole('link', { name: /View all/ })).toHaveAttribute('href', '/transactions')

    unmount()
    const revisit = render(<MemoryRouter><Dashboard /></MemoryRouter>)
    expect(revisit.container.querySelector('.dashboard-entrance')).not.toBeInTheDocument()
  })

  it('shows the first-expense empty state and opens the quick-add flow', () => {
    useDashboard.mockReturnValue({
      data: {
        totalBalance: 0,
        todaySpent: 0,
        monthSpent: 0,
        monthIncome: 0,
        monthNet: 0,
        period: { timezone: 'Asia/Kolkata' },
        wallets: [],
        topCategories: [],
        recent: [],
      },
      isPending: false,
      isError: false,
      refetch: vi.fn(),
    })
    const openQuickAdd = vi.spyOn(window, 'dispatchEvent')

    render(<MemoryRouter><Dashboard /></MemoryRouter>)

    fireEvent.click(screen.getByRole('button', { name: 'Add your first expense' }))
    expect(openQuickAdd).toHaveBeenCalledWith(expect.objectContaining({ type: 'smart-spend:open-quick-add' }))
    expect(document.querySelector('.empty-jar-illustration')).toBeInTheDocument()
  })

  it('highlights a transaction that appears after the initial dashboard data', () => {
    const initialData = {
      totalBalance: 0,
      todaySpent: 0,
      monthSpent: 0,
      monthIncome: 0,
      monthNet: 0,
      period: { timezone: 'Asia/Kolkata' },
      wallets: [],
      topCategories: [],
      recent: [],
    }
    useDashboard.mockReturnValue({
      data: initialData,
      isPending: false,
      isError: false,
      refetch: vi.fn(),
    })
    const view = render(<MemoryRouter><Dashboard /></MemoryRouter>)

    useDashboard.mockReturnValue({
      data: {
        ...initialData,
        recent: [{
          id: 'new-expense',
          type: 'expense',
          amount: 1200,
          merchant: 'Lunch',
          txnDate: '2026-10-20T10:00:00.000Z',
          walletId: { name: 'Cash' },
        }],
      },
      isPending: false,
      isError: false,
      refetch: vi.fn(),
    })
    view.rerender(<MemoryRouter><Dashboard /></MemoryRouter>)

    expect(screen.getByText('Lunch').closest('li')).toHaveClass('transaction-highlight')
  })
})
