import { useAuth } from '@/hooks/useAuth.js'
import PageHeader from '@/components/common/PageHeader.jsx'
import GlassCard from '@/components/common/GlassCard.jsx'
import ThemeToggle from '@/components/common/ThemeToggle.jsx'
import LogoutButton from '@/components/layout/LogoutButton.jsx'
import { USER_TYPES } from '@/lib/constants.js'

function Settings() {
  const { user } = useAuth()
  const userType = USER_TYPES.find(({ value }) => value === user?.userType)?.label ?? user?.userType ?? '—'

  return (
    <>
      <PageHeader
        description="Manage your account and app preferences."
        eyebrow="Preferences"
        title="Settings"
      />
      <div className="grid gap-4 md:grid-cols-2">
        <GlassCard className="rounded-2xl" variant="strong">
          <h2 className="font-semibold">Profile</h2>
          <dl className="mt-5 space-y-4">
            <div>
              <dt className="text-xs text-muted-foreground">Name</dt>
              <dd className="mt-1 text-sm font-medium">{user?.name || '—'}</dd>
            </div>
            <div>
              <dt className="text-xs text-muted-foreground">Email</dt>
              <dd className="mt-1 break-all text-sm font-medium">{user?.email || '—'}</dd>
            </div>
            <div>
              <dt className="text-xs text-muted-foreground">Who are you?</dt>
              <dd className="mt-1 text-sm font-medium">{userType}</dd>
            </div>
          </dl>
          <LogoutButton className="mt-6" variant="outline" />
        </GlassCard>
        <GlassCard className="rounded-2xl" variant="strong">
          <h2 className="font-semibold">Appearance</h2>
          <p className="mt-1 text-sm text-muted-foreground">Choose how Smart Spend looks on this device.</p>
          <div className="mt-5 max-w-sm">
            <ThemeToggle />
          </div>
        </GlassCard>
      </div>
    </>
  )
}

export default Settings
