import { useMemo, useState } from 'react'
import { Plus, ReceiptText, Trash2 } from 'lucide-react'
import { m } from 'motion/react'
import { toast } from 'sonner'
import { useSearchParams } from 'react-router-dom'
import { useAuth } from '@/hooks/useAuth.js'
import { useMotionDisabled } from '@/hooks/useMotionDisabled.js'
import { useTransactions } from '@/hooks/useTransactions.js'
import { useTrash } from '@/hooks/useTrash.js'
import { useTransactionMutations } from '@/hooks/useTransactionMutations.js'
import PageHeader from '@/components/common/PageHeader.jsx'
import TransactionForm from '@/components/transactions/TransactionForm.jsx'
import TransactionList, { TrashList } from '@/components/transactions/TransactionList.jsx'
import {
  activeTransactionFilterCount,
  TransactionFilters,
  transactionFiltersFromParams,
} from '@/components/transactions/TransactionFilters.jsx'
import { Button } from '@/components/ui/button.jsx'

function Transactions() {
  const [searchParams, setSearchParams] = useSearchParams()
  const { user } = useAuth()
  const timeZone = user?.timezone || 'Asia/Kolkata'
  const isTrash = searchParams.get('view') === 'trash'
  const motionDisabled = useMotionDisabled()
  const [editingTransaction, setEditingTransaction] = useState(null)
  const [formOpen, setFormOpen] = useState(false)
  const mutations = useTransactionMutations()
  const filters = useMemo(() => transactionFiltersFromParams(searchParams), [searchParams])
  const transactionsQuery = useTransactions(filters, !isTrash)
  const trashQuery = useTrash(isTrash)
  const transactions = useMemo(
    () => (transactionsQuery.data?.pages ?? []).flatMap((page) => page.data ?? []),
    [transactionsQuery.data],
  )
  const trashTransactions = trashQuery.data ?? []
  const filterCount = activeTransactionFilterCount(searchParams)

  function setView(view) {
    setSearchParams((current) => {
      const next = new URLSearchParams(current)
      if (view === 'trash') next.set('view', 'trash')
      else next.delete('view')
      return next
    }, { replace: true })
  }

  function clearFilters() {
    setSearchParams((current) => {
      const next = new URLSearchParams(current)
      for (const key of ['q', 'type', 'walletId', 'categoryId', 'datePreset', 'from', 'to', 'fromDate', 'toDate', 'minAmount', 'maxAmount', 'tag']) {
        next.delete(key)
      }
      return next
    }, { replace: true })
  }

  function beginCreate() {
    setEditingTransaction(null)
    setFormOpen(true)
  }

  function beginEdit(transaction) {
    setEditingTransaction(transaction)
    setFormOpen(true)
  }

  function deleteTransaction(transaction) {
    const id = transaction.id ?? transaction._id
    mutations.remove.mutate(id, {
      onSuccess: () => {
        toast('Moved to trash', {
          duration: 6000,
          action: {
            label: 'Undo',
            onClick: () => mutations.restore.mutate(id, {
              onSuccess: () => toast.success('Transaction restored'),
            }),
          },
        })
      },
    })
  }

  function restoreTransaction(transaction) {
    mutations.restore.mutate(transaction.id ?? transaction._id, {
      onSuccess: () => toast.success('Transaction restored'),
    })
  }

  return (
    <>
      <PageHeader
        action={!isTrash && (
          <Button onClick={beginCreate}>
            <Plus aria-hidden="true" />
            Add transaction
          </Button>
        )}
        description="Review and manage your spending in one place."
        eyebrow="Your activity"
        title="Transactions"
      />
      <div className="space-y-5">
        <div aria-label="Transaction lists" className="flex w-full gap-2 border-b border-border/70" role="tablist">
          <button
            aria-selected={!isTrash}
            className={`relative inline-flex items-center gap-2 border-b-2 border-transparent px-3 py-2 text-sm font-semibold ${!isTrash ? 'text-foreground' : 'text-muted-foreground'}`}
            onClick={() => setView('all')}
            role="tab"
            type="button"
          >
            {!isTrash && <m.span aria-hidden="true" className="absolute inset-x-0 bottom-[-1px] h-0.5 bg-primary" layoutId="transaction-view-indicator" transition={motionDisabled ? { duration: 0 } : { type: 'spring', stiffness: 420, damping: 34 }} />}
            <span className="relative z-10 inline-flex items-center gap-2">
            <ReceiptText aria-hidden="true" className="size-4" />All
            </span>
          </button>
          <button
            aria-selected={isTrash}
            className={`relative inline-flex items-center gap-2 border-b-2 border-transparent px-3 py-2 text-sm font-semibold ${isTrash ? 'text-foreground' : 'text-muted-foreground'}`}
            onClick={() => setView('trash')}
            role="tab"
            type="button"
          >
            {isTrash && <m.span aria-hidden="true" className="absolute inset-x-0 bottom-[-1px] h-0.5 bg-primary" layoutId="transaction-view-indicator" transition={motionDisabled ? { duration: 0 } : { type: 'spring', stiffness: 420, damping: 34 }} />}
            <span className="relative z-10 inline-flex items-center gap-2">
            <Trash2 aria-hidden="true" className="size-4" />Trash
            </span>
          </button>
        </div>

        {isTrash ? (
          <TrashList
            isError={trashQuery.isError}
            isLoading={trashQuery.isPending}
            isRestoring={mutations.restore.isPending}
            onRestore={restoreTransaction}
            onRetry={() => trashQuery.refetch()}
            timeZone={timeZone}
            transactions={trashTransactions}
          />
        ) : (
          <>
            <TransactionFilters params={searchParams} setParams={setSearchParams} timeZone={timeZone} />
            <p className="text-sm text-muted-foreground" aria-live="polite">
              {transactionsQuery.data?.pages?.[0]?.pagination?.total ?? 0} transactions
              {filterCount > 0 ? ` · ${filterCount} active ${filterCount === 1 ? 'filter' : 'filters'}` : ''}
            </p>
            <TransactionList
              hasFilters={filterCount > 0}
              highlightKey={JSON.stringify(filters)}
              hasNextPage={transactionsQuery.hasNextPage}
              isError={transactionsQuery.isError}
              isFetchNextPageError={transactionsQuery.isFetchNextPageError}
              isFetchingNextPage={transactionsQuery.isFetchingNextPage}
              isLoading={transactionsQuery.isPending}
              onClearFilters={clearFilters}
              onDelete={deleteTransaction}
              onEdit={beginEdit}
              onLoadMore={() => transactionsQuery.fetchNextPage()}
              onRetry={() => transactionsQuery.refetch()}
              timeZone={timeZone}
              transactions={transactions}
            />
          </>
        )}
      </div>
      {formOpen && (
        <TransactionForm
          key={editingTransaction ? editingTransaction.id ?? editingTransaction._id : 'new'}
          mutations={mutations}
          onClose={() => setFormOpen(false)}
          timeZone={timeZone}
          transaction={editingTransaction}
        />
      )}
    </>
  )
}

export default Transactions
